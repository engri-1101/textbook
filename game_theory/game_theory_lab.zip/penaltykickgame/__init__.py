from . import penalty_kick_automated_game as main_game
