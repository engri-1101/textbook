from . import game_stats_figure_1 as stats_fig_1
from . import game_stats_figure_2 as stats_fig_2
from . import game_stats_figure_3 as stats_fig_3
from . import game_stats_figure_4 as stats_fig_4
from . import main_game_figure as game_fig
